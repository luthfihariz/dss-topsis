<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateForeignKeys extends Migration {

	public function up()
	{
		Schema::table('nilai', function(Blueprint $table) {
			$table->foreign('kriteria_id')->references('id')->on('kriteria')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('nilai_warga', function(Blueprint $table) {
			$table->foreign('nilai_id')->references('id')->on('warga')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
		Schema::table('nilai_warga', function(Blueprint $table) {
			$table->foreign('warga_id')->references('id')->on('warga')
						->onDelete('restrict')
						->onUpdate('restrict');
		});
	}

	public function down()
	{
		Schema::table('nilai', function(Blueprint $table) {
			$table->dropForeign('nilai_kriteria_id_foreign');
		});
		Schema::table('nilai_warga', function(Blueprint $table) {
			$table->dropForeign('nilai_warga_nilai_id_foreign');
		});
		Schema::table('nilai_warga', function(Blueprint $table) {
			$table->dropForeign('nilai_warga_warga_id_foreign');
		});
	}
}